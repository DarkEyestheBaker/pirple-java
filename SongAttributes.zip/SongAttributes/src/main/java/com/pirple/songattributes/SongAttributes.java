//Song information for "Hey, Brother!" for Julie Dietsch's java homework on variables.
package com.pirple.songattributes;

public class SongAttributes {
    public static void main(String[] args) {
        System.out.println();
        System.out.println("(Song information for \"Hey, Brother!\" for Julie Dietsch's java homework on variables.)");
        System.out.println();
        System.out.println();
        String song = "Hey, Brother!";
        String genre = "Folktronic";
        String released = "October 09, 2013";
        float duration = 4.14f;
        String label = "Universal";
        String producer = "Avicii";
        String lyrics = "[Verse 1]\n" +
"Hey Brother! There’s an endless road to rediscover 1\n" +
"Hey Sister! Know the water’s sweet but blood is thicker 2\n" +
"Oh! If the sky comes falling down\n" +
"For you\n" +
"There’s nothing in this world I wouldn’t do 3\n" +
"\n" +
"[Verse 2]\n" +
"Hey Brother! Do you still believe in one another? 4\n" +
"Hey Sister! Do you still believe in love? I wonder 5\n" +
"Oh! If the sky comes falling down\n" +
"For you\n" +
"There’s nothing in this world I wouldn’t do 6\n" +
"\n" +
"[Chorus]\n" +
"What if I’m far from home? Oh Brother, I will hear you call! 7\n" +
"What if I lose it all? Oh Sister, I will help you out! 8\n" +
"Oh! If the sky comes falling down\n" +
"For you\n" +
"There’s nothing in this world I wouldn’t do\n" +
"\n" +
"Beat break\n" +
"\n" +
"[Verse 3]\n" +
"Hey Brother! There’s an endless road to rediscover 9\n" +
"Hey Sister! Do you still believe in love? I wonder\n" +
"Oh! If the sky comes falling down\n" +
"For you\n" +
"There’s nothing in this world I wouldn’t do\n" +
"\n" +
"[Chorus]\n" +
"What if I’m far from home? Oh Brother, I will hear you call!\n" +
"What if I lose it all? Oh Sister, I will help you out! 10\n" +
"Oh! If the sky comes falling down\n" +
"For you\n" +
"There’s nothing in this world I wouldn’t do 11";
        
        System.out.println("Song title: " + song);
        System.out.println("Genre: " + genre);
        System.out.println("Release date: " + released);
        System.out.println("Duration: " + duration);
        System.out.println("Recording label: " + label);
        System.out.println("Produced by: " + producer);
        System.out.println("Song lyrics: ");
        System.out.println(lyrics);
        System.out.println();
        System.out.println();
        
        
        
        
    }
    
}
