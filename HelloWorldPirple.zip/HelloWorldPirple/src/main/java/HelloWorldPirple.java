
public class HelloWorldPirple {
    public static void main(String[] args) {
        System.out.println("Hello, Pirple World!");
    }
    }
